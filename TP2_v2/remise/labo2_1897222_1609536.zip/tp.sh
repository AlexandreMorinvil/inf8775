#!/bin/sh
python3 traveler-solver.py "$@"